// Command.java
public interface Command {
    void execute();
}
