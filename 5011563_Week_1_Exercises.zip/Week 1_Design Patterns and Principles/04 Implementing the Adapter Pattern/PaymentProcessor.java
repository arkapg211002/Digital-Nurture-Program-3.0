// PaymentProcessor.java
public interface PaymentProcessor {
    void processPayment(double amount);
}
